
extern size_t remoteconfig_cmdlength( const char *src_buf, const char *src_end );
